package com.example.aut2_03aplicacinfinalandroid.ui.actividad2;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class Actividad2ViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public Actividad2ViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Segunda actividad");
    }

    public LiveData<String> getText() {
        return mText;
    }
}