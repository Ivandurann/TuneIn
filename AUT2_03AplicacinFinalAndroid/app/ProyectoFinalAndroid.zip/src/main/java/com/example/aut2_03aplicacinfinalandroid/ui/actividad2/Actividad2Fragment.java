package com.example.aut2_03aplicacinfinalandroid.ui.actividad2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.aut2_03aplicacinfinalandroid.databinding.FragViewActividad2Binding;

public class Actividad2Fragment extends Fragment {

    private FragViewActividad2Binding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        Actividad2ViewModel homeViewModel =
                new ViewModelProvider(this).get(Actividad2ViewModel.class);

        binding = FragViewActividad2Binding.inflate(inflater, container, false);
        View root = binding.getRoot();

        /* final TextView textView = binding.textActividad2;
        homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText); */
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}