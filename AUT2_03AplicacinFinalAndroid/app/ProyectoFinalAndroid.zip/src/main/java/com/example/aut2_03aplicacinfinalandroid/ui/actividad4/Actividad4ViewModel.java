package com.example.aut2_03aplicacinfinalandroid.ui.actividad4;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class Actividad4ViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public Actividad4ViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Esta es la cuarta");
    }

    public LiveData<String> getText() {
        return mText;
    }
}