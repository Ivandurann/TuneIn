package com.example.aut2_03aplicacinfinalandroid.ui.actividad3;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class Actividad3ViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public Actividad3ViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Tercera actividad");
    }

    public LiveData<String> getText() {
        return mText;
    }
}