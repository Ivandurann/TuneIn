package com.example.aut2_03aplicacinfinalandroid.ui.actividad1;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class Actividad1ViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public Actividad1ViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Esta es la primera actividad");
    }

    public LiveData<String> getText() {
        return mText;
    }
}